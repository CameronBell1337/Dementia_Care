Name: Cameron Bell
Student Number: 1702819

REPO: https://github.com/CameronBell1337/Dementia_Care

5 Minutes Demo preview: https://www.youtube.com/watch?v=EHYzMgOy1tI

Virutal machine used: Pixel 4 XL with API 29 and android O;

Physical devices used: Samsung Note 8, Samsung S20 Ultra, Samsung S8 Plus, Samsung A12, Google Pixel 5 (Using beta version of android 12)